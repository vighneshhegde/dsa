/*******************************************************************
*           DSA Lab Test 2: Problem 1 (extras.c)
*   
*  Implement any support data structures in this file, if required.
* ******************************************************************/
#include "extras.h"
#include <assert.h>
#include <stdio.h>
#include <malloc.h>

// Write your code here.
#include <stdlib.h>
void conTreeRec(tree t, unsigned int *list, unsigned int st, unsigned int en)
{
	if(st==en) return;
	int mid;
	t = (tree)malloc(sizeof(struct _tnode));
	t->data = list[st];
	st++;

	int prob = rand()%3;
	if(prob == LEMPTY){
		conTreeRec(t->right,list, st,en);
	}
	else if(prob==REMPTY){
		conTreeRec(t->left, list, st, en);
	}
	else{
		mid = (en-st)/2;
		conTreeRec(t->left, list, st, mid);
		conTreeRec(t->right,list, mid+1, en);
	}

}
/*
void shift(unsigned int *list, int len){
	int i;
	for(i=0;i<len;i++){
		list[i] = list[i+1];
	}
	
}*/
