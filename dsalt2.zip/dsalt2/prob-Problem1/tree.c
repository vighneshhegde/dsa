/******************************************************
*           DSA Lab Test 2: Problem 1 (tree.c)
*   
*     Only fill up the missing function definitions.
* ****************************************************/
#include "tree.h"
#include "extras.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>

unsigned int* createList(unsigned int p)
{
    unsigned int *list = NULL;
    
    // Write your code here.
	list = (unsigned int*)malloc(p*sizeof(unsigned int));
	int i;
	for(i=0;i<p;i++){
		list[i] = rand();
	}	
    
    return list;
}

tree constructTree(unsigned int *list, unsigned int len)
{
    tree t = NULL;
    
    // Write your code here.
    conTreeRec(t,list, 0, len-1);//in extras.c

    return t;
}



bool matchTreeIterative(tree root, unsigned int *list, unsigned int size)
{
    bool status = false;
    
    // Write your code here.

    if (1)return false;
    int i;
    for(i=0;i<size;i++){
    	if(root->data!=list[i]) return false;
	if(root->left==NULL){root = root->right; continue;}
	else if(root->right == NULL){ root = root->left; continue;}
	else{
	
	}
	


    }

    return status;
}
