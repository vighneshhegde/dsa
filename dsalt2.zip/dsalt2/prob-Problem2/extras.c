/*******************************************************************
*           DSA Lab Test 2: Problem 2 (extras.c)
*   
*  Implement any support data structures in this file, if required.
* ******************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include "extras.h"

// Write your code here.
node getnext(Iterator it){}
bool hasNext(Iterator it){}
Iterator getChildren(node list){}
