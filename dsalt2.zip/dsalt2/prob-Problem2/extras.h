/*******************************************************************
*           DSA Lab Test 2: Problem 2 (extras.h)
*   
*  Interface any support data structures in this file, if required.
* ******************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include "graph.h"

#ifndef EXTRAS_H_INCLUDED
#define EXTRAS_H_INCLUDED


// Write your code here.
#include<string.h>

typedef struct {
	node* arr;
	int index;
	int length;
}Iterator;

node getnext(Iterator it);
bool hasNext(Iterator it);
Iterator getChildren(node list);
#endif
