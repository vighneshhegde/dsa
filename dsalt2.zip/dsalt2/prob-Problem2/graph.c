/******************************************************
*           DSA Lab Test 2: Problem 2 (graph.c)
*   
*     Only fill up the missing function definitions.
* ****************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include "graph.h"
#include "extras.h"


Graph initGraph(int N)
{
    Graph g = NULL;
    
    // Write your code here.
	g = (Graph)malloc(sizeof(struct _Graph));
	g->list = (node)calloc(N,sizeof(struct _node));
	int i;
	for(i=0;i<N;i++) g->list[i].id = -1;
	g->wt = (int*)calloc(N,sizeof(int));
	g->visited = (bool*)calloc(N,sizeof(bool));
	g->ecount = 0;
	g->vcount = N;
    
    return g;
}
void printAdjacencyList(Graph g)
{
    // Write your code here.
	int i;
	for(i=0;i<g->vcount;i++){
		printf("\n%d\t(%d) ==> ",i,g->wt[i]);
		node current;

		for(current = (g->list+i);current!=NULL; current=current->next){
			printf("%u\t",current->id);
		}
	//	printf("\n");
	}
		
}

void insertEdge(Graph g, unsigned int u, unsigned int v)
{
    // Write your code here.
	node current;	
	for(current = (g->list+u);current!=NULL; current=current->next){
		if(current->id==v) return;
	}


	current = (node)malloc(sizeof(struct _node));
	memcpy(current,g->list+u,sizeof(struct _node));

	node new = (node)malloc(sizeof(struct _node));
	new->id = v;
	new->next = current;
	memcpy(g->list+u, new,sizeof(struct _node));
	g->ecount++;
	free(current);
//	printAdjacencyList(g);
}
void bestFirstTraverse(Graph g, unsigned int root)
{
    // Write your code here.
	if(g->list+root==NULL) return;
	printf("%d ",root);
	Iterator ch = getChildren(g->list+root);//sorted according to weight
	while(hasNext(ch)){
		node temp = getnext(ch);
		bestFirstTraverse(g, temp->id);

	} 

}
