#include "List.h"

int globalCounter;


	
List createList(Student studArray, int arraySize){
	List sl = (List)myalloc(sizeof(struct list));
	int i;
	Node new = (Node)myalloc(sizeof(struct node));
	new->next->record = (Student)myalloc(sizeof(struct student));
	*new->record= studArray[0];
	sl->first = new;

	for(i=1;i<arraySize;i++){
		new->next = (Node)myalloc(sizeof(struct node));
		new->next->record = (Student)myalloc(sizeof(struct student));
		*new->next->record = studArray[i];
		new = new->next; 
	}
	sl->last = new;
	sl->last->next = NULL;

	return sl;

}

void insertInOrder(List list, Node newNode){
	if(list->first == NULL || strcmp(newNode->record->name,list->first->record->name)){
		newNode->next = list->first;
		list->first = newNode;
	}	
	else{
		Node current = list->first;
		while(current->next == NULL){
			if(strcmp(current->record->name,newNode->record->name) && strcmp(newNode->record->name,current->next->record->name)){
				
				newNode->next = current->next;
				current->next = newNode;
				break;
			} 
			current= current->next;
		}
		if(newNode->next = NULL){
			list->last->next = newNode;
			list->last = newNode;
		}
	}
	list->count++;
}

List insertionSort(List list){
	List sl = (List)myalloc(sizeof(struct list));
	sl->count = 0;
	int i;
	int n = list->count;
	Node current = list->first; 
	for(i = 0; i<n; i++){
		insertInOrder(sl, current);
		current = current->next;
		sl->count++;
	}

	return sl;
}

double measureSortingTime(List list){
	struct timeval t1,t2;
	double elapsedtime;
	
	gettimeofday(&t1,NULL);

	insertionSort(list);

	gettimeofday(&t2,NULL);
	
	elapsedtime = (t2.tv_sec - t1.tv_sec)/1000;
	elapsedtime += (t2.tv_usec - t2.tv_usec)*1000;

	return elapsedtime;
}

void * myalloc(int size){
	void* mem = malloc(size + sizeof(int));
	if(mem==NULL) return mem;
	globalCounter += size;		
	*(int*)mem = size; 
	return (mem+sizeof(int));
}

void myfree(void* ptr){
	globalCounter -= *(int*)(ptr - sizeof(int));
	free(ptr - sizeof(int));
}
