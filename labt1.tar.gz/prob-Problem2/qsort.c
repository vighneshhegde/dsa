#include "qsort.h"

int size = 0;

void printArray(int* studArray, int arrSize)
{
	// printing the array
	int i = 0;
	for(i=0;i<arrSize;i++)
	{
		printf("Arr[%d] is %d\n", i, studArray[i]);
	}
}



int* readData(char * fileName){
	FILE* f = fopen(fileName, "r");
	fscanf(f,"%d\n", &size);
	int* arr = (int*)malloc(size * sizeof(int));

	int i;
	for(i=0;i<size && !feof(f);i++){
		fscanf(f,"%*s %d",&arr[i]);
	}
	return arr;
}

KeyStruct extractKeys(int* Ls, int lsSize, int loKey, int hiKey){
	KeyStruct kst = (KeyStruct)malloc(sizeof(struct keyStruct));
	int n = hiKey - loKey;
	int i,count=0;


	kst->Keys = (int*)calloc(hiKey - loKey, sizeof(int));
	kst->keysSize = n;

	for(i = 0; i<n; i++){
		kst->Keys[i] = -9999; //NULL value
	}
	
	for(i = 0; i<lsSize ;i++){
		kst->Keys[Ls[i]-loKey] = Ls[i];//overwrite if duplicates occur
	}
	//discard all values where key does not occur

	KeyStruct kst2 = (KeyStruct)malloc(sizeof(struct keyStruct));
	kst2->Keys = (int*)calloc(hiKey - loKey, sizeof(int));

	for(i = 0; i<n; i++){
		if(kst->Keys[i]!= -9999){
			kst2->Keys[count++] = kst->Keys[i];
		}
	}
	kst2->keysSize = count;
	return kst2;
}

int part2Loc(int* Ls, int lo, int hi, int piv){
	int k = Ls[piv];
	swap(&Ls[piv],&Ls[lo]);
	int md = lo, bdry = lo+1;
	while(bdry<=hi){
		if(Ls[bdry]<=k){
			swap(&Ls[bdry],&Ls[md+1]);
			md++;
		}
		bdry++;
	}
	swap(&Ls[lo],&Ls[md]);


	return md;	
}

void quickSortKnownKeyRange(int * Ls, int size, int loKey, int hiKey){
	
	KeyStruct kst = extractKeys(Ls, size, loKey, hiKey);

	// printing the keys array
	int i = 0;
	for(i=0;i<kst->keysSize;i++)
	{
		printf("Keys[%d] is %d\n", i, kst->Keys[i]);
	}
	
	int stack[size];
	int top = -1;
	for(i = 0; i<kst->keysSize; i++){
		part2Loc(Ls, 0, size-1, i);
	}	


}

void swap(int* a, int* b){
	int temp = *a;
	*a = *b;
	*b = temp;
}
